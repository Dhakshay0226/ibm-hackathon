"""
Thin wrapper around an OpenAI-compatible chat completion endpoint.

Why this shape: IBM watsonx.ai, OpenAI, Groq, and most modern LLM hosts all
expose an OpenAI-compatible /chat/completions route. Keeping this file the
only place that knows about the API means swapping providers is a one-line
change to your .env, not a code rewrite.

Set these in backend/.env (see .env.example):
    LLM_API_KEY=...
    LLM_BASE_URL=...      # e.g. https://us-south.ml.cloud.ibm.com/ml/v1  (watsonx)
    LLM_MODEL=...         # e.g. ibm/granite-13b-instruct-v2, or gpt-4o-mini, etc.
"""
import os
import json
from openai import OpenAI

_client = None


def get_client():
    global _client
    if _client is None:
        _client = OpenAI(
            api_key=os.environ.get("LLM_API_KEY", "not-set"),
            base_url=os.environ.get("LLM_BASE_URL") or None,
        )
    return _client


def _model():
    return os.environ.get("LLM_MODEL", "gpt-4o-mini")


def chat(system_prompt: str, user_prompt: str, json_mode: bool = False, max_tokens: int = 1200):
    client = get_client()
    kwargs = {}
    if json_mode:
        kwargs["response_format"] = {"type": "json_object"}

    resp = client.chat.completions.create(
        model=_model(),
        max_tokens=max_tokens,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        **kwargs,
    )
    return resp.choices[0].message.content


def chat_json(system_prompt: str, user_prompt: str, max_tokens: int = 1500):
    """Call chat() expecting JSON back, with a fallback parse attempt."""
    raw = chat(system_prompt, user_prompt, json_mode=True, max_tokens=max_tokens)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        # Some providers ignore response_format; strip code fences and retry.
        cleaned = raw.strip().strip("`")
        if cleaned.startswith("json"):
            cleaned = cleaned[4:]
        return json.loads(cleaned)
