import os
import io
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import PyPDF2

import llm_client

load_dotenv()

app = Flask(__name__)
CORS(app)

MAX_NOTES_CHARS = 12000  # keep prompts small & cheap; truncate long uploads


def extract_text(file_storage):
    filename = file_storage.filename.lower()
    if filename.endswith(".pdf"):
        reader = PyPDF2.PdfReader(file_storage.stream)
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    return file_storage.stream.read().decode("utf-8", errors="ignore")


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


@app.route("/api/upload", methods=["POST"])
def upload_notes():
    """Accepts a .txt/.md/.pdf file OR raw pasted text, returns cleaned text."""
    if "file" in request.files:
        text = extract_text(request.files["file"])
    else:
        text = (request.json or {}).get("text", "")

    text = text.strip()[:MAX_NOTES_CHARS]
    if not text:
        return jsonify({"error": "No text extracted"}), 400
    return jsonify({"text": text, "chars": len(text)})


@app.route("/api/explain", methods=["POST"])
def explain():
    """'Explain like I'm 10' style simplification of uploaded notes."""
    data = request.json or {}
    notes = data.get("notes", "")[:MAX_NOTES_CHARS]
    level = data.get("level", "eli10")  # eli10 | eli-undergrad | exam-crunch

    level_prompts = {
        "eli10": "Explain this like the reader is a curious 10-year-old. Use simple words, short sentences, and one relatable analogy per concept. No jargon without an immediate plain-English definition.",
        "eli-undergrad": "Explain this at a first-year undergraduate level. Keep technical terms but define them on first use. Be concise and structured.",
        "exam-crunch": "Summarize this into tight, exam-ready bullet points. Prioritize definitions, formulas, and things likely to be tested. No fluff.",
    }
    system = (
        "You are a patient, encouraging study buddy for a student. "
        + level_prompts.get(level, level_prompts["eli10"])
        + " Structure your answer with clear headings for each major topic found in the notes."
    )
    result = llm_client.chat(system, notes, max_tokens=1500)
    return jsonify({"explanation": result})


@app.route("/api/quiz", methods=["POST"])
def quiz():
    """Generates multiple-choice quiz questions from notes, structured JSON."""
    data = request.json or {}
    notes = data.get("notes", "")[:MAX_NOTES_CHARS]
    num_questions = int(data.get("num_questions", 5))
    difficulty = data.get("difficulty", "medium")

    system = (
        "You generate multiple-choice quiz questions from study notes for a Kahoot-style quiz. "
        "Return ONLY valid JSON, no prose, in this exact shape:\n"
        '{"questions": [{"question": str, "options": [str, str, str, str], '
        '"correct_index": int, "explanation": str}]}\n'
        f"Generate exactly {num_questions} questions at {difficulty} difficulty. "
        "Each question must be answerable strictly from the provided notes. "
        "Distractors (wrong options) must be plausible, not obviously wrong."
    )
    result = llm_client.chat_json(system, notes, max_tokens=1800)
    return jsonify(result)


@app.route("/api/revision-plan", methods=["POST"])
def revision_plan():
    """Generates a day-by-day revision plan from notes + days available."""
    data = request.json or {}
    notes = data.get("notes", "")[:MAX_NOTES_CHARS]
    days = int(data.get("days", 7))
    hours_per_day = data.get("hours_per_day", 2)

    system = (
        "You are a study planner. Break the provided notes into topics, then build a day-by-day "
        f"revision plan spanning exactly {days} days, assuming about {hours_per_day} focused hours "
        "per day. Weight earlier days toward foundational/harder topics and later days toward "
        "review + practice questions. Return ONLY valid JSON in this shape:\n"
        '{"plan": [{"day": int, "topics": [str], "tasks": [str], "est_hours": number}]}'
    )
    result = llm_client.chat_json(system, notes, max_tokens=1800)
    return jsonify(result)


@app.route("/api/doubt", methods=["POST"])
def doubt():
    """Doubt-solving chatbot grounded in the uploaded course notes."""
    data = request.json or {}
    notes = data.get("notes", "")[:MAX_NOTES_CHARS]
    question = data.get("question", "")
    history = data.get("history", [])  # list of {role, content}

    system = (
        "You are a doubt-solving assistant for a student. Answer ONLY using the course notes "
        "provided below. If the answer isn't in the notes, say so clearly and give a brief "
        "general explanation, marking it as 'not directly in your notes'.\n\n"
        f"COURSE NOTES:\n{notes}"
    )
    client = llm_client.get_client()
    messages = [{"role": "system", "content": system}] + history + [
        {"role": "user", "content": question}
    ]
    resp = client.chat.completions.create(
        model=llm_client._model(),
        max_tokens=800,
        messages=messages,
    )
    return jsonify({"answer": resp.choices[0].message.content})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
